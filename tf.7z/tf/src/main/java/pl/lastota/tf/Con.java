package pl.lastota.tf;

import org.apache.commons.io.IOUtils;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import javax.servlet.http.HttpServletResponse;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.util.Random;

@RestController
public class Con {


    @RequestMapping(value = "/{file}", method = RequestMethod.GET)
    public void getImageAsByteArray(@PathVariable("file") String file, HttpServletResponse response) throws IOException {
        File initialFile = new File("/home/adam/Desktop/tf/" + file + ".mp3");
        System.out.println("TST: " + file);
        InputStream in = new FileInputStream(initialFile);
        response.setContentType("audio/mpeg");
        IOUtils.copy(in, response.getOutputStream());
    }

    @RequestMapping(value = "/randQuestion", method = RequestMethod.GET)
    public String randQuestion(HttpServletResponse response) {
        String s = "q_" + (new Random().nextInt((7 - 1) + 1) + 1) + ";1"  ;
        System.out.println("qyestion: "+ s);
        return s;
    }
}
